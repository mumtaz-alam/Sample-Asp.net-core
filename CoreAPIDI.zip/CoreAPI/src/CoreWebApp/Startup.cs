﻿using System;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using CoreWebApp.BL;
using LightInject;
using LightInject.Microsoft.DependencyInjection;
using Autofac;
using Autofac.Extensions.DependencyInjection;

namespace CoreWebApp
{
    public class Startup
    {
        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                .AddEnvironmentVariables();

            if (env.IsDevelopment())
            {
                // This will push telemetry data through Application Insights pipeline faster, allowing you to view results immediately.
                builder.AddApplicationInsightsSettings(developerMode: true);
            }
            Configuration = builder.Build();
        }

        public IConfigurationRoot Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public IServiceProvider ConfigureServices(IServiceCollection services)
        {
            // Add framework services.
            services.AddApplicationInsightsTelemetry(Configuration);
            //services.AddSingleton<IStudentBL, StudentBL>();
            services.AddMvc();
            //return ServiceProviderFactory.GetServiceProvider(services, Configuration);
            /*LightInject
                        var container = new ServiceContainer();
                        container.Register<IStudentBL, StudentBL>();
                        return container.CreateServiceProvider(services);
                        */
            /*AutoFac*/
            var builder = new ContainerBuilder();
            builder.RegisterType<StudentBL>().As<IStudentBL>();
            builder.Populate(services);

            var appContainer = builder.Build();

            return new AutofacServiceProvider(appContainer);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            loggerFactory.AddDebug();

            app.UseApplicationInsightsRequestTelemetry();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseBrowserLink();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseApplicationInsightsExceptionTelemetry();

            app.UseStaticFiles();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
    public static class ServiceProviderFactory
    {
        public static IServiceProvider GetServiceProvider(IServiceCollection services, IConfiguration configuration)
        {
            services.AddApplicationInsightsTelemetry(configuration);
            var container = new ServiceContainer();
            services.AddMvc();
            //services.RegisterDbContexts(configuration.GetConnectionString("recipibookdb"));
            return container.CreateServiceProvider(services);
        }
    }
}

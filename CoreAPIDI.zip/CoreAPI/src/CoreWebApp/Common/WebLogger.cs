﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System;
using System.IO;
using context = System.Web.HttpContext; 

namespace company.CIO.IOSM.ROM.Common
{
    /// <summary>
    /// WebLogger
    /// </summary>
    public static class WebLogger
    {
        /// <summary>
        /// LogException
        /// </summary>
        /// <param name="ex"></param>
        public static void LogException(Exception ex,string MethodName)
        {
            try
            {
                string filepath = context.Current.Server.MapPath("~/App_Data/");  //Text File Path

                if (!Directory.Exists(filepath))
                {
                    Directory.CreateDirectory(filepath);

                }
                filepath = filepath + "ROM_" + DateTime.Today.ToString("dd-MM-yy") + ".txt";   //Text File Name
                if (!File.Exists(filepath))
                {
                    File.Create(filepath).Dispose();
                }
                using (StreamWriter sw = File.AppendText(filepath))
                {
                    sw.WriteLine("-----------Exception Details on " + " " + DateTime.Now.ToString() + "-----------------");  
                    if (ex.InnerException != null)
                    {
                        sw.Write("Inner Exception Type: ");
                        sw.WriteLine(ex.InnerException.GetType().ToString());
                        sw.Write("Inner Exception: ");
                        sw.WriteLine(ex.InnerException.Message);
                       
                        sw.WriteLine(ex.InnerException.Message);
                        sw.Write("Inner Source: ");
                        sw.WriteLine(ex.InnerException.Source);
                        if (ex.InnerException.StackTrace != null)
                        {
                            sw.WriteLine("Inner Stack Trace: ");
                            sw.WriteLine(ex.InnerException.StackTrace);
                        }
                    }
                    if (!string.IsNullOrEmpty(MethodName))
                    {
                        sw.WriteLine(String.Format("An error occured in the method {0} at {1}:", MethodName, DateTime.Now.ToString()));
                        sw.WriteLine("MethodName: " + MethodName);
                    }
                    sw.Write("Exception Type: ");
                    sw.WriteLine(ex.GetType().ToString());
                    sw.WriteLine("Exception: " + ex.Message);
                    sw.WriteLine("Source: " + ex.Source);
                    sw.WriteLine("Stack Trace: ");
                    if (ex.StackTrace != null)
                    {
                        sw.WriteLine(ex.StackTrace);
                        sw.WriteLine();
                    }
                    sw.WriteLine("--------------------------------*End*------------------------------------------");  
                    sw.Flush();
                    sw.Close();

                }

            }
            catch (Exception e)
            {
                e.ToString();

            }
        }

        public static void WriteEntry(string type, string module)
        {
            try
            {
                string filepath = context.Current.Server.MapPath("~/App_Data/");  //Text File Path

                if (!Directory.Exists(filepath))
                {
                    Directory.CreateDirectory(filepath);

                }
                filepath = filepath + "ROM_ServiceLog_" + DateTime.Today.ToString("dd-MM-yy") + ".txt";   //Text File Name
                if (!File.Exists(filepath))
                {
                    File.Create(filepath).Dispose();
                }
                using (StreamWriter sw = File.AppendText(filepath))
                {
                    sw.WriteLine(string.Format("{0},{1},{2}",
                                      DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                                      type,
                                      module));
                    sw.Flush();
                    sw.Close();

                }

            }
            catch (Exception e)
            {
                e.ToString();

            }
        }
    }
}*/

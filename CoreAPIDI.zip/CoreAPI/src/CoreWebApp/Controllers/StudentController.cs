﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CoreWebApp.BL;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace CoreWebApp.Controllers
{
    public class StudentController : Controller
    {
        public IStudentBL _stdob { get; set; }
        public StudentController(IStudentBL std) {
            _stdob = std;
        }

        // GET: /<controller>/
        public async Task<IActionResult> Index()
        {
            var result = await _stdob.GetAsyAll(@"http://localhost:58168/");
            return View(result);
        }
    }
}

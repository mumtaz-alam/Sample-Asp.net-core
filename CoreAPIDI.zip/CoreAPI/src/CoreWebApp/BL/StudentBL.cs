﻿using CoreWebApp.ViewModels;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace CoreWebApp.BL
{
    public class StudentBL:IStudentBL
    {

        public Task<List<Student>> GetAll() {

            return CallApi(@"http://localhost:58168/");

        }



        public async Task<List<Student>> CallApi(string url)
        {
            var retValue = new List<Student>();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(url);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = await client.GetAsync("api/students");
                if (response.IsSuccessStatusCode)
                {
                    var s = await response.Content.ReadAsStringAsync();

                    retValue = JsonConvert.DeserializeObject<List<Student>>(s);
                }
            }
            return await Task.FromResult(retValue);

        }


        public async Task<List<Student>> GetAsyAll(string url)
        {
            var retValue = new List<Student>();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(url);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = await client.GetAsync("api/students");
                if (response.IsSuccessStatusCode)
                {
                    var s = await response.Content.ReadAsStringAsync();

                    retValue = JsonConvert.DeserializeObject<List<Student>>(s);
                }
            }
            return retValue;
        }
    }
}

﻿using CoreWebApp.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreWebApp.BL
{
   public interface IStudentBL
    {
         Task<List<Student>> GetAll();
         Task<List<Student>> CallApi(string url);
        Task<List<Student>> GetAsyAll(string url);
    }
}

﻿using CoreAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreAPI.DAL
{
    public interface IRepository : IDisposable
    {
        IEnumerable<Student> GetEntity(Int32 pageSize, Int32 pageNumber, String name);

        Student GetEntity(Int32? id);

        Student AddEntity(Student entity);

        Student UpdateEntity(Int32? id, Student changes);

        Student DeleteEntity(Int32? id);
    }
}

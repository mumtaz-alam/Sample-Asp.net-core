﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
namespace CoreAPI.DAL
{
    public interface IEntityMapper
    {
        IEnumerable<IEntityMap> Mappings { get; }

        void MapEntities(ModelBuilder modelBuilder);
    }
}

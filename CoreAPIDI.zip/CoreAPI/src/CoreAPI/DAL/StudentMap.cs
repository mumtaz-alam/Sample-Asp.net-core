﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using CoreAPI.Models;

namespace CoreAPI.DAL
{
    public class StudentMap : IEntityMap
    {
        public void Map(ModelBuilder modelBuilder)
        {
            var entity = modelBuilder.Entity<Student>();

            entity.ToTable("Student", "dbo");

            entity.HasKey(p => new { p.RollId });

            entity.Property(p => p.RollId).UseSqlServerIdentityColumn();
        }
    }
}

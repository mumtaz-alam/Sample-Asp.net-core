﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreAPI.Models
{
    public class StudentCollection
    {
      private  ConcurrentDictionary<int, Student> _stus = new ConcurrentDictionary<int, Student>();

        public StudentCollection()
        {
            _stus= new ConcurrentDictionary<int, Student>();
        }
        public ConcurrentDictionary<int, Student> stdColl {

            get {
                return _stus;
                    }
            set
            {
                _stus = value;
            }
                
        }
    }
}

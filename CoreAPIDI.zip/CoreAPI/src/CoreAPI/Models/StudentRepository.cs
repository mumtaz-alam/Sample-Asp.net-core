﻿using Autofac;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LightInject;
namespace CoreAPI.Models
{
    public class StudentRepository : IStudentRepository
    {
        private ConcurrentDictionary<int, Student> _stus { get; set; }
        private StudentsDBContext _context;
        public StudentRepository(ConcurrentDictionary<int, Student> sts)
        {
            //using (var scope = Startup.contnr.BeginLifetimeScope())
            //{
            //    _stus = scope.Resolve<ConcurrentDictionary<int, Student>>();
            //}
            //using (Startup.Servicecontnr.BeginScope())
            //{

            //    //var firstInstance = Startup.Servicecontnr.GetInstance<ConcurrentDictionary<int, Student>>();
            //    var secondInstance = _stus = Startup.Servicecontnr.GetInstance<ConcurrentDictionary<int, Student>>();
            //    //Assert.AreSame(firstInstance, secondInstance);
            //    var cnt = Startup.Servicecontnr.GetAllInstances<ConcurrentDictionary<int, Student>>().Count();
            //}
            _stus = sts;
            //Add(new Student { Name = "Item" + (_stus.Count() + 1).ToString() });
            //_context = context;
        }
        public StudentRepository(StudentsDBContext context)
        {
            Add(new Student { Name = "Item"+ (_stus.Count() + 1).ToString() });
            //_context = context;
        }
        public void Add(Student item)
        {
            item.RollId = _stus.Count()+1;
            _stus[item.RollId] = item;

               // _context.Students.Add(item);
               // _context.SaveChanges();

        }

        public Student Find(int key)
        {
            Student item;
            _stus.TryGetValue(key, out item);
            return item;
        }

        public IEnumerable<Student> GetAll()
        {
           //return _context.Students.ToList();
            return _stus.Values;
        }

        public Student Remove(int key)
        {
            Student item;
            _stus.TryRemove(key, out item);
            return item;
        }

        public void Update(Student item)
        {
            _stus[item.RollId] = item;
        }
    }
}

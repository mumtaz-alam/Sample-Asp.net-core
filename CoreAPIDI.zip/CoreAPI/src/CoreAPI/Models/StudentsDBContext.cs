﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CoreAPI.Models
{
    public partial class StudentsDBContext : DbContext
    {
        public virtual DbSet<Marks> Marks { get; set; }
        public virtual DbSet<Student> Students { get; set; }
        public StudentsDBContext(DbContextOptions<StudentsDBContext> options)
        : base(options)
        { }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Marks>(entity =>
            {
                entity.HasKey(e => e.MarkId)
                    .HasName("PK_Marks");

                //entity.HasOne(d => d.Roll)
                //    .WithMany(p => p.Marks)
                //    .HasForeignKey(d => d.RollId);
            });

            modelBuilder.Entity<Student>(entity =>
            {
                entity.HasKey(e => e.RollId)
                    .HasName("PK_Student");

                entity.Property(e => e.Name).IsRequired();
            });
        }
    }
}
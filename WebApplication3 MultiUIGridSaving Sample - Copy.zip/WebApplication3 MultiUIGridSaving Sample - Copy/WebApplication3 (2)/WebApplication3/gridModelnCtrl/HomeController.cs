﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index(string id)
        {
            return View();
        }
        public string GetCountry()
       {
            List<CountryModel> obj = new List<CountryModel>();
            obj.Add(new CountryModel() { CountryValue = 1, CareerTrackValue = 1, EconomicProfileValue = 1, LoadTypeValue = 1, RateTypeValue = 1, Percentage = "25%" });
            obj.Add(new CountryModel() { CountryValue = 1, CareerTrackValue = 1, EconomicProfileValue = 1, LoadTypeValue = 1, RateTypeValue = 1, Percentage = "25%" });
            obj.Add(new CountryModel() { CountryValue = 1, CareerTrackValue = 1, EconomicProfileValue = 1, LoadTypeValue = 1, RateTypeValue = 1, Percentage = "25%" });
            //, LoadTypeValue = 1, RateTypeValue = 1
            //, LoadTypeValue = 1, RateTypeValue = 1
            //, LoadTypeValue = 1, RateTypeValue = 1
             List<Country> ObjCountry = new List<Country>();
            ObjCountry.Add(new Country() { id = 1, value = "India" });
            ObjCountry.Add(new Country() { id = 2, value = "Philipiness" });
            ObjCountry.Add(new Country() { id = 3, value = "Japan" });
            obj[0].CountryList = ObjCountry;
            List<CareerTrack> ObjCareerTrack = new List<CareerTrack>();
            ObjCareerTrack.Add(new CareerTrack() { id = 1, value = "abc" });
            ObjCareerTrack.Add(new CareerTrack() { id = 2, value = "def" });
            ObjCareerTrack.Add(new CareerTrack() { id = 3, value = "ghi" });
            obj[0].CareerTrackList = ObjCareerTrack;
            List<EconomicProfile> ObjEconomicProfile = new List<EconomicProfile>();
            ObjEconomicProfile.Add(new EconomicProfile() { id = 1, value = "Lead SMe" });
            ObjEconomicProfile.Add(new EconomicProfile() { id = 2, value = "Contractor" });
            ObjEconomicProfile.Add(new EconomicProfile() { id = 3, value = "Leadership" });
            obj[0].EconomicProfileList = ObjEconomicProfile;
            List<LoadType> objLoadType = new List<LoadType>();
            objLoadType.Add(new LoadType() { id = 1, value = "Standard" });
            objLoadType.Add(new LoadType() { id = 2, value = "Avanade" });
            obj[0].LoadTypeList = objLoadType;
            List<RateType> objRateType = new List<RateType>();
            objRateType.Add(new RateType() { id = 1, value = "Shared" });
            objRateType.Add(new RateType() { id = 2, value = "Individual" });
            obj[0].RateTypeList = objRateType;
        //1.enableGridMenu
        //2.enableSorting
        //3.enableFiltering
        //4.enableHorizontalScrollbar

            //return (new UIGridCustom()).UIGridTable(obj, "", "", "Percentage:10%~10", "", "CountryValue,CareerTrackValue,EconomicProfileValue,Percentage", "enableGridMenu,enableSorting,enableFiltering,enableHorizontalScrollbar");
            return (new UIGridCustom()).UIGridTable(obj, "", "", "", "", "", "");
       }

        public string GetEmp1()
        {

            List<Employee> emps = new List<Employee>();
            emps.Add(new Employee() { Id = 1, Name = "AAA", Add = "Ad1", Age = 21, Salary = 1000, Lvl = 0, GenderValue = 1, SexValue = 1});
            emps.Add(new Employee() { Id = 10, Name = "AAA", Add = "Ad10", Age = 30, Salary = 10000, Lvl = 1, GenderValue = 1, SexValue = 2 });
            emps.Add(new Employee() { Id = 2, Name = "BBB", Add = "Ad2", Age = 22, Salary = 2000, Lvl = 1, GenderValue = 1, SexValue = 1});
            emps.Add(new Employee() { Id = 2, Name = "CCC", Add = "Ad3", Age = 23, Salary = 3000, Lvl = 1, GenderValue = 1, SexValue = 1 });
            emps.Add(new Employee() { Id = 3, Name = "CCC1", Add = "Ad3", Age = 23, Salary = 3000, Lvl = 1, GenderValue = 1, SexValue = 1 });
            emps.Add(new Employee() { Id = 5, Name = "EEE1", Add = "Ad5", Age = 25, Salary = 5000, Lvl = 1, GenderValue = 2, SexValue = 2 });
            emps.Add(new Employee() { Id = 6, Name = "FFF1", Add = "Ad6", Age = 26, Salary = 6000, Lvl = 1, GenderValue = 1, SexValue = 1 });
            emps.Add(new Employee() { Id = 7, Name = "HHH1", Add = "Ad7", Age = 27, Salary = 7000, Lvl = 1, GenderValue = 2, SexValue = 2 });
            emps.Add(new Employee() { Id = 8, Name = "III1", Add = "Ad8", Age = 28, Salary = 8000, Lvl = 1, GenderValue = 1, SexValue = 1 });
            emps.Add(new Employee() { Id = 9, Name = "JJJ1", Add = "Ad9", Age = 29, Salary = 8000, Lvl = 1, GenderValue = 2, SexValue = 2 });
            
            List<Gender> li = new List<Gender>();
            li.Add(new Gender() { id = 1, value = "Male" });
            li.Add(new Gender() { id = 2, value = "Female" });
            emps[0].GenderList = li;
            List<Sex> si = new List<Sex>();
            si.Add(new Sex() { id = 1, value = "M" });
            si.Add(new Sex() { id = 2, value = "F" });
            emps[0].SexList = si;
            //NO SPACE Should be there between defining the parameter
            CustProp objImg = new CustProp() { Name = "Img", DispName = "", ColTemplate = @"<div class='ui-grid-cell-contents'><img id='FillImg{{rowRenderIndex}}' src='../Content/Img/arrow.png'/ width='10px\'  ng-click='grid.appScope.Autofill(rowRenderIndex)'></div>" };
            emps[0].imgCust = objImg;
            return (new UIGridCustom()).UIGridTable(emps, "", "", "", "", "", ""); //NO SPACE Should be there between defining the parameter
        }
        public string GetStudent()
        {
            //Employee[] emps = new Employee[] {
            //new Employee() { Id = 1, Name = "AAA", Add = "Add1", Age = 21, Salary = 1000 },
            //new Employee() { Id = 2, Name = "BBB", Add = "Add2", Age = 22, Salary = 2000 },
            //new Employee() { Id = 3, Name = "CCC", Add = "Add3", Age = 23, Salary = 3000 },
            //new Employee() { Id = 4, Name = "DDD", Add = "Add4", Age = 24, Salary = 4000 },
            //new Employee() { Id = 5, Name = "EEE", Add = "Add5", Age = 25, Salary = 5000 },
            //new Employee() { Id = 6, Name = "FFF", Add = "Add6", Age = 26, Salary = 6000 },
            //new Employee() { Id = 7, Name = "HHH", Add = "Add7", Age = 27, Salary = 7000 },
            //new Employee() { Id = 8, Name = "III", Add = "Add8", Age = 28, Salary = 8000 },
            //new Employee() { Id = 9, Name = "JJJ", Add = "Add9", Age = 29, Salary = 8000 },
            //new Employee() { Id = 10, Name = "AAA", Add = "Add1", Age = 21, Salary = 10000 }
            //        };

            List<Student> std = new List<Student>();
            std.Add(new Student() { Id = 1, Name = "AAA1", Add = "Ad1", Age = 21, Marks = 1000, Lvl =1, GenderValue = 1, SexValue = 1 });
            //emps.Add(new Employee() { Id = 2, Name = "BBB1", Add = "Ad2", Age = 22, Salary = 2000, Lvl = 1, GenderValue = 1, SexValue = 1 });
            //emps.Add(new Employee() { Id = 4, Name = "DDD1", Add = "Ad4", Age = 24, Salary = 4000, Lvl = 1, GenderValue = 2, SexValue = 2 });
            //emps.Add(new Employee() { Id = 3, Name = "CCC1", Add = "Ad3", Age = 23, Salary = 3000, Lvl = 1, GenderValue = 1, SexValue = 1 });
            //emps.Add(new Employee() { Id = 5, Name = "EEE1", Add = "Ad5", Age = 25, Salary = 5000, Lvl = 1, GenderValue = 2, SexValue = 2 });
            //emps.Add(new Employee() { Id = 6, Name = "FFF1", Add = "Ad6", Age = 26, Salary = 6000, Lvl = 1, GenderValue = 1, SexValue = 1 });
            //emps.Add(new Employee() { Id = 7, Name = "HHH1", Add = "Ad7", Age = 27, Salary = 7000, Lvl = 1, GenderValue = 2, SexValue = 2 });
            //emps.Add(new Employee() { Id = 8, Name = "III1", Add = "Ad8", Age = 28, Salary = 8000, Lvl = 1, GenderValue = 1, SexValue = 1 });
            //emps.Add(new Employee() { Id = 9, Name = "JJJ1", Add = "Ad9", Age = 29, Salary = 8000, Lvl = 1, GenderValue = 2, SexValue = 2 });
            //emps.Add(new Employee() { Id = 10, Name = "AAA1", Add = "Ad10", Age = 30, Salary = 10000, Lvl = 1, GenderValue = 1, SexValue = 2 });

            List<Gender> li = new List<Gender>();
            li.Add(new Gender() { id = 1, value = "Male" });
            li.Add(new Gender() { id = 2, value = "Female" });
            std[0].GenderList = li;
            List<Sex> si = new List<Sex>();
            si.Add(new Sex() { id = 1, value = "M" });
            si.Add(new Sex() { id = 2, value = "F" });
            std[0].SexList = si;
            //List<Rate> ri = new List<Rate>();
            //ri.Add(new Rate() { id = 1, value = "R1" });
            //ri.Add(new Rate() { id = 2, value = "R2" });
            //ri.Add(new Rate() { id = 3, value = "R3" });
            //ri.Add(new Rate() { id = 4, value = "R4" });
            //emps[0].RateList = ri;
            //return new JavaScriptSerializer().Serialize(emps);
            //string response = JsonConvert.SerializeObject(emps);
            //return response;
            //return UIGridCustom.UIGridTable(emps, "Name", "AVG(Salary)", "Name,Add,Age", "Name,Add,Age");
            //return UIGridCustom.UIGridTable(emps, "", "", "Name:20%-10,Add:20%-10,Age:20%-10,Salary:20%-10", "Name,Add,Age", "Name,Add,Age");,Treelevel:1%~10 
            //NO SPACE Should be there between defining the parameter
            return (new UIGridCustom()).UIGridTable(std, "", "", "", "", "", ""); ; //NO SPACE Should be there between defining the parameter
        }
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        //[HttpPost]
        public string WriteLog(string id)
        {
            System.IO.File.AppendAllText(@"C:\data\Log.txt", DateTime.Now.ToString() + "--" + id + Environment.NewLine);
            return "";
        }

        public string SaveEmp1(string JsonDataSource)
        {
            List<Employee> lstEmp = (List<Employee>)Newtonsoft.Json.JsonConvert.DeserializeObject(JsonDataSource, typeof(List<Employee>));
            return "";
        }
        public string SaveEmp2(string JsonDataSource)
        {
            List<Employee> lstEmp = (List<Employee>)Newtonsoft.Json.JsonConvert.DeserializeObject(JsonDataSource, typeof(List<Employee>));
            return "";
        }
        public string SaveStd(string JsonDataSource)
        {
            List<Student> lstEmp = (List<Student>)Newtonsoft.Json.JsonConvert.DeserializeObject(JsonDataSource, typeof(List<Student>));
            return "";
        }
    }

}
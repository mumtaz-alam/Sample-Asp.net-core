﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication3.Models
{
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Add { get; set; }
        public int Age { get; set; }
        public int Marks { get; set; }
        public int GenderValue { get; set; }
        public List<Gender> GenderList { get; set; }
        public int SexValue { get; set; }
        public List<Sex> SexList { get; set; }
        //public int RateValue { get; set; }
        //public List<Rate> RateList { get; set; }
        public int Lvl { get; set; }
    }
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Add { get; set; }
        public int Age { get; set; }
        public int Salary { get; set; }
        public int GenderValue { get; set; }
        public List<Gender> GenderList { get; set; }
        public int SexValue { get; set; }
        public List<Sex> SexList { get; set; }
        //public int RateValue { get; set; }
        //public List<Rate> RateList { get; set; }
        public int Lvl { get; set; }
        public CustProp imgCust { get; set; }
    }
    public class Gender
    {
        public int id { get; set; }
        public string value { get; set; }
    }
    public class Sex
    {
        public int id { get; set; }
        public string value { get; set; }
    }
    public class Rate
    {
        public int id { get; set; }
        public string value { get; set; }
    }
    public class drplist
    {
        public List<Rate> RateList { get; set; }
        public List<Gender> GenderList { get; set; }
        public List<Sex> SexList { get; set; }
    }
    public class CustProp
    {
        public string Name { get; set; }
        public string DispName { get; set; }
        public string ColTemplate { get; set; }
    }



    public class CountryModel
    {
        public int ID { get; set; }
        public int CountryValue { get; set; }
        public List<Country> CountryList { get; set; }
        public int CareerTrackValue { get; set; }
        public List<CareerTrack> CareerTrackList { get; set; }
        public int EconomicProfileValue { get; set; }
        public List<EconomicProfile> EconomicProfileList { get; set; }
        public int LoadTypeValue { get; set; }
        public List<LoadType> LoadTypeList { get; set; }
        public int RateTypeValue { get; set; }
        public List<RateType> RateTypeList { get; set; }
        public string Percentage { get; set; }
    }
    public class Country
    {
        public int id { get; set; }
        public string value { get; set; }
    }
    public class CareerTrack
    {
        public int id { get; set; }
        public string value { get; set; }
    }
    public class EconomicProfile
    {
        public int id { get; set; }
        public string value { get; set; }
    }
    public class RateType
    {
        public int id { get; set; }
        public string value { get; set; }
    }
    public class LoadType
    {
        public int id { get; set; }
        public string value { get; set; }
    }
}
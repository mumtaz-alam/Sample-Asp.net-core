﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RestaurantReviewSample.Models
{
    public class _demoPartial1Models
    {
        public _demoPartial1Models()
        {
            for (double d = 0; d < 100000; d = d + .001)
            {
                id = Convert.ToInt32(d);
            }
        }
        public string type;
        public int id;
    }
}
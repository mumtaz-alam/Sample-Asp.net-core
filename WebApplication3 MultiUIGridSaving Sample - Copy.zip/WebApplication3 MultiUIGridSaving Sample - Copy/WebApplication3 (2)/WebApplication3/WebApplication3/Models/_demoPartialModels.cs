﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RestaurantReviewSample.Models
{
    
    public class _demoPartialModels
    {
        public string type;
        public int id;
        public string PMessage { get; set; }

        
    }

    //public class ChildModel
    //{
    //    public string type;
    //    public int id;
    //    public string ChildProperty { get; set; }
    //}

    public class MainModel
    {
        public _demoPartialModels TestModel { get; set; }
        public string  Message { get; set; }
               
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace System.Web.Mvc
{
    public static class MultiplePartialViews
    {
        public static PartialViewsResult PartialViews(this Controller controller, string[] views)
        {
            return PartialViews(controller, views, null);
        }
        public static PartialViewsResult PartialViews(this Controller controller, string[] views, object[] model)
        {
            if (model != null)
            {
                controller.ViewData.Model = model;
            }

            return new PartialViewsResult
            {
                ViewName = "",
                ViewData = controller.ViewData,
                TempData = controller.TempData,
                ViewEngineCollection = controller.ViewEngineCollection,
                Views = views
            };
        }
    }
    public class PartialViewsResult : PartialViewResult
    {
        public IEnumerable<string> Views;

        protected override ViewEngineResult FindView(ControllerContext context)
        {
            return base.FindView(context);
        }
        public override void ExecuteResult(ControllerContext context)
        {
            if (context == null)
                throw new ArgumentNullException("context");
            if (!Views.Any())
                throw new Exception("no view...");


            TextWriter writer = context.HttpContext.Response.Output;
            for (int i = 0; i < Views.Count();i++ )
            //foreach (var view in Views)
            {
                this.ViewName = Views.ToArray()[i];
                ViewEngineResult result = FindView(context);
                ViewDataDictionary vdd = new ViewDataDictionary(((object[])(ViewData.Model))[i]);
                
                ViewContext viewContext = new ViewContext(context, result.View, vdd, TempData, writer);
                //ViewContext viewContext = new ViewContext();
                // viewContext.Controller = context.Controller;
                // viewContext.Controller.ControllerContext = context;
                //viewContext.View = result.View;
                //viewContext.ViewData = ViewData;
                //viewContext.TempData = TempData;
                //viewContext.Writer = writer;
                result.View.Render(viewContext, writer);

                result.ViewEngine.ReleaseView(context, result.View);
            }
        }
    }
}
﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


    public class UIGridCustom
    {
        public string UIGridTable(dynamic datasource, string GroupByColumn = "", string AggregateColumnExpr = "",string visibleColListWithWidthnHight="", string filterColList = "", string EditableColList = "",string GridProperty="")
        {
            string response = JsonConvert.SerializeObject(datasource);
            if (GroupByColumn != string.Empty)
            foreach (string str in GroupByColumn.Split(','))
            {
                response = response.Replace(GroupByColumn, GroupByColumn + "!");
            }
            if (AggregateColumnExpr != string.Empty)
            {
                //response = response.Replace(GroupByColumn, GroupByColumn + "!");
                AggregateColumnExpr = AggregateColumnExpr.Replace("SUM(", "S(").Replace("MAX(", "X(").Replace("MIN(", "N(").Replace("AVG(", "A(");
                var s = AggregateColumnExpr.Replace(")", "");
                AggregateColumnExpr = s.Split('(')[1];
                response = response.Replace(AggregateColumnExpr, AggregateColumnExpr + "@" + s.Split('(')[0]);

            }
            if (filterColList != string.Empty)
            foreach (string str in filterColList.Split(','))
            {
                response = response.Replace(str, str + "#");
            }
            if (EditableColList != string.Empty)
            foreach (string str in EditableColList.Split(','))
            {
                response = response.Replace(str, str + "&");
            }
            if (visibleColListWithWidthnHight != string.Empty)
            foreach (string str in visibleColListWithWidthnHight.Split(','))
            {
                string tmpstr = str.Split(':')[0];
                response = response.Replace(tmpstr, tmpstr + "^" + str.Split(':')[1]);
            }
            //if (GridProperty != string.Empty)
            //{
            //    string opt="*";
            //    foreach (string str in GridProperty.Split(','))
            //    {
            //        //1.enableGridMenu
            //        //2.enableSorting
            //        //3.enableFiltering
            //        //4.enableHorizontalScrollbar
            //        if(str.ToLower()=="enablegridmenu")
            //            opt = opt + "1";
            //        if (str.ToLower() == "enablesorting")
            //            opt = opt + "2";
            //        if (str.ToLower() == "enablefiltering")
            //            opt = opt + "3";
            //        if (str.ToLower() == "enableHorizontalScrollbar")
            //            opt = opt + "4";
            //    }
            //    response = response.Replace("ID\":", "ID"+opt+"\":" );
            //}
            return response; 
        }
    }

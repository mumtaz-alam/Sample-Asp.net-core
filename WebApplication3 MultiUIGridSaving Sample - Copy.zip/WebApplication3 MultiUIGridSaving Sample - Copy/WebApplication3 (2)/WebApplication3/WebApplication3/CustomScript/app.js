function CallAngularSave()
{
    alert('Save');
    angular.element(document.getElementById('testdiv')).scope().save('grid1', '/Home/SaveStd');
}


function SaveCustomGrid(Grid, action) {

    var scope = angular.element($("#" + Grid)).scope();
    var JsonDataSource = "";
    var ctrlAction = action;
    JsonDataSource = JSON.stringify(scope.gridOptions.data);

    $.ajax({
        cache: false,
        type: "POST",
        url: ctrlAction,
        //contentType: "application/json; charset=utf-8",
        data: { "JsonDataSource": JsonDataSource },
        dataType: "json",
        success: function (data) {
            //scope.$apply(function () {

            //})
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(thrownError);
        }
    });
}

function WriteLog(msg) {
    //debugger;
    $.ajax({
        cache: false,
        type: "POST",
        url: "/Home/WriteLog" + "/" + msg,
        contentType: "application/json; charset=utf-8",
        async: false,
        dataType: "json",
        success: function (data) {

        },
        error: function (xhr, ajaxOptions, thrownError) {
            // alert('wwwwww Failed to retrieve states.');
        }
    });
}
//debugger;
function CreateCustomGridAjax(Grid, action, uiGridGroupingConstants,asyncall, gridoption,GroupByColumn,AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList) {//, Dropdowns, DropdwnIdx

    var scope = angular.element($("#" + Grid)).scope();
    gridoption = gridoption.toUpperCase();
    if (gridoption.indexOf('ENABLEGRIDMENU') != -1)
        scope.gridOptions.enableGridMenu = true;
    if (gridoption.indexOf('ENABLESORTING') != -1)
        scope.gridOptions.enableSorting = true;
    if (gridoption.indexOf('ENABLEFILTERING') != -1)
        scope.gridOptions.enableFiltering = true;
    if (gridoption.indexOf('ENABLEHORIZONTALSCROLLBAR') != -1)
        scope.gridOptions.enableHorizontalScrollbar = true;
    if (gridoption.indexOf('ENABLEFULLROWSELECTION') != -1)
        scope.gridOptions.enableFullRowSelection= true;
    

    var ctrlAction = action;// "/Home/" +
    $.ajax({
        cache: false,
        type: "POST",
        url: ctrlAction,
        //data: { "ManagedServiceId": selectedItem },
        contentType: "application/json; charset=utf-8",
        async: asyncall,
        dataType: "json",
        success: function (data) {
            try {
                //alert('kkkk');
                //WriteLog('Reterived Data');
                $.each(data[0], function (key, value) {
                    var filterFlag = false;
                    var EditableFlag = false;
                    var Offset = -1;
                    var col = key;
                    var w = '*';
                    var h = '10';
                    var delKey = false
                    //alert(key);
                    visibleColListWithWidthnHight = visibleColListWithWidthnHight.toUpperCase();
                    var KEY = key.toUpperCase()
                    if (visibleColListWithWidthnHight.indexOf(KEY) != -1) {//Height and width of column
                        //EditableFlag = true;

                        var size = visibleColListWithWidthnHight.split(",");
                        for (var i = 0; i < size.length; i++) {
                            var pos = size[i].indexOf(KEY);
                            if (size[i].indexOf(KEY) != -1)
                            {
                                Offset = size[i].indexOf(":");
                                var hPos = size[i].indexOf('~');
                                w = size[i].substr(Offset + 1, hPos - (Offset + 1));
                                if (w == '0%') {
                                    return;
                                }
                            }
                        }

                    }
                    filterColList = filterColList.toUpperCase();
                    if (filterColList.indexOf(key.toUpperCase()) != -1) {
                        filterFlag = true;
                    }
                    EditableColList = EditableColList.toUpperCase();
                    if (EditableColList.indexOf(key.toUpperCase()) != -1) {//Editable column
                        EditableFlag = true;
                    }


                    if (key.indexOf('Value') != -1) {//Dropdown column
                        //col = (Offset != -1) ? key.substr(0, Offset) : key.substr(0, pos);
                        col = key.substr(0, key.indexOf('Value'))
                        scope.columns.push({
                            field: key, displayName: col, width: w, editableCellTemplate: 'ui-grid/dropdownEditor',
                            cellFilter: 'mapFunction' + scope.DropdwnIdx + ':grid.appScope', resizable: true, enableFiltering: filterFlag //,editDropdownValueLabel: 'Sex',
                        });
                        scope.DropdwnIdx++;
                        return;
                    }

                    if (key.indexOf('Cust') != -1) {//Custom column
                        col = value.DispName;
                        var colTemp = value.ColTemplate;
                        scope.columns.push({
                            field: value.Name, displayName: col, width: w, cellTemplate: colTemp, resizable: true, enableFiltering: filterFlag //,editDropdownValueLabel: 'Sex',
                        });
                        return;
                    }

                    GroupByColumn = GroupByColumn.toUpperCase();
                    if (GroupByColumn.indexOf(key.toUpperCase()) != -1) {
                        scope.columns.push({ width: w, enableFiltering: filterFlag, field: col, displayName: col, enableCellEdit: true, grouping: { groupPriority: 1 }, sort: { priority: 1, direction: 'asc' }, resizable: true });
                    }
                    else {
                        //AggregateColumnExpr = AggregateColumnExpr.toUpperCase();
                        if (AggregateColumnExpr.toUpperCase().indexOf(key.toUpperCase()) != -1) {
                            var arrExpr = AggregateColumnExpr.split("(");
                            col = arrExpr[1].substr(0,arrExpr[1].length-1);
                            if (arrExpr[0].toUpperCase() == 'SUM')
                                scope.columns.push({ field: col, displayName: col, enableCellEdit: EditableFlag, enableFiltering: true, treeAggregationType: uiGridGroupingConstants.aggregation.SUM, width: w, resizable: true });
                            if (arrExpr[0].toUpperCase() == 'MAX')
                                scope.columns.push({ field: col, displayName: col, enableCellEdit: EditableFlag, enableFiltering: true, treeAggregationType: uiGridGroupingConstants.aggregation.MAX, width: w, resizable: true });
                            if (arrExpr[0].toUpperCase() == 'MIN')
                                scope.columns.push({ field: col, displayName: col, enableCellEdit: EditableFlag, enableFiltering: true, treeAggregationType: uiGridGroupingConstants.aggregation.MIN, width: w, resizable: true });
                            if (arrExpr[0].toUpperCase() == 'AVG')
                                scope.columns.push({ field: col, displayName: col, enableCellEdit: EditableFlag, enableFiltering: true, treeAggregationType: uiGridGroupingConstants.aggregation.AVG, width: w, resizable: true });

                        }
                        else {
                            if (key.toUpperCase().indexOf('ID') != -1) {
                                //scope.columns.push({ visible: false, field: col, displayName: col, enableCellEdit: EditableFlag, enableFiltering: filterFlag, resizable: true });//resizable: true
                            }
                            else {
                                if (key.toUpperCase().indexOf('LVL') != -1) {
                                    scope.columns.push({ visible: false, field: col, displayName: col, enableCellEdit: EditableFlag, enableFiltering: filterFlag, resizable: true });
                                }
                                else
                                    scope.columns.push({ width: w, field: col, displayName: col, enableCellEdit: EditableFlag, enableFiltering: filterFlag, resizable: true });
                            }
                        }
                    }
                })
                //WriteLog('Processed Data');

                var i = 0, j = 0;


                $.each(data[0], function (key, value) {
                    //alert($scope.gridOptions.columnDefs[i].displayName);
                    var colname = scope.gridOptions.columnDefs[i].displayName;
                    if (i < scope.gridOptions.columnDefs.length) {
                        var drpIdx = colname.indexOf('List');
                        if (drpIdx != -1) {
                            scope.Dropdowns[j] = new Array(1);
                            scope.Dropdowns[j] = scope.gridOptions.columnDefs[i - 1].editDropdownOptionsArray = value;//data[0].GenderList;
                            //scope.gridOptions.columnDefs[i].visible = false;

                            j++;
                        }
                    }
                    if (key.indexOf(colname) == -1) {
                        for (var x = 0; x < data.length; x++) {
                            delete data[x][key];
                        }
                    }
                    else {
                        i++;
                    }

                })

                for (var y = 0; y < scope.gridOptions.columnDefs.length; y++) {
                    var colname = scope.gridOptions.columnDefs[y].displayName;
                    if (colname.indexOf('List') != -1 || colname.indexOf('Lvl') != -1) {
                        scope.columns.splice(y, 1);
                        y--;
                    }
                }

                for (var l = 0; l < data.length; l++) {
                    if (data[l].Lvl == 0)
                        data[l].$$treeLevel = 0;
                    //else
                    //    data[l].$$treeLevel = 1;
                }


                //var pt = /[*^#&@]/g;
                //var jsonData = JSON.stringify(data).split("\":")
                //var clrdata = "";
                //for (var i = 0; i < jsonData.length; i++) {
                //    var ind = jsonData[i].search(pt);
                //    var clrkey = (ind != -1) ? jsonData[i].substr(0, ind) : jsonData[i];
                //    //alert(clrkey);
                //    clrdata = clrdata + clrkey + "\":";
                //}
                //clrdata = clrdata.substr(0, clrdata.length - 2);
                //clrdata = JSON.parse(clrdata);
                //scope.gridOptions.data = clrdata;
                scope.gridOptions.data = data;
                //WriteLog('Binded Data');
            }
            catch (err) {
                message.innerHTML = err.message;
                //alert(err.message);
            }
        }
    });
}
function CreateCustomGrid(http, Grid, action, uiGridGroupingConstants, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList) {//, Dropdowns, DropdwnIdx
    debugger;
    var scope = angular.element($("#" + Grid)).scope();
    gridoption = gridoption.toUpperCase();
    if (gridoption.indexOf('ENABLEGRIDMENU') != -1)
        scope.gridOptions.enableGridMenu = true;
    if (gridoption.indexOf('ENABLESORTING') != -1)
        scope.gridOptions.enableSorting = true;
    if (gridoption.indexOf('ENABLEFILTERING') != -1)
        scope.gridOptions.enableFiltering = true;
    if (gridoption.indexOf('ENABLEHORIZONTALSCROLLBAR') != -1)
        scope.gridOptions.enableHorizontalScrollbar = true;
    //if (gridoption.indexOf('ENABLEFULLROWSELECTION') != -1)
    //    scope.gridOptions.enableFullRowSelection= true;
    debugger;

    var ctrlAction = action;// "/Home/" +
    http.get(ctrlAction)
    .success(function (data) {
        try {
            //alert('kkkk');
            //WriteLog('Reterived Data');
            $.each(data[0], function (key, value) {
                var filterFlag = false;
                var EditableFlag = false;
                var Offset = -1;
                var col = key;
                var w = '*';
                var h = '10';
                var delKey = false
                //alert(key);
                visibleColListWithWidthnHight = visibleColListWithWidthnHight.toUpperCase();
                var KEY = key.toUpperCase()
                if (visibleColListWithWidthnHight.indexOf(KEY) != -1) {//Height and width of column
                    //EditableFlag = true;

                    var size = visibleColListWithWidthnHight.split(",");
                    for (var i = 0; i < size.length; i++) {
                        var pos = size[i].indexOf(KEY);
                        if (size[i].indexOf(KEY) != -1) {
                            Offset = size[i].indexOf(":");
                            var hPos = size[i].indexOf('~');
                            w = size[i].substr(Offset + 1, hPos - (Offset + 1));
                            if (w == '0%') {
                                return;
                            }
                        }
                    }

                }
                filterColList = filterColList.toUpperCase();
                if (filterColList.indexOf(key.toUpperCase()) != -1) {
                    filterFlag = true;
                }
                EditableColList = EditableColList.toUpperCase();
                if (EditableColList.indexOf(key.toUpperCase()) != -1) {//Editable column
                    EditableFlag = true;
                }


                if (key.indexOf('Value') != -1) {//Dropdown column
                    //col = (Offset != -1) ? key.substr(0, Offset) : key.substr(0, pos);
                    col = key.substr(0, key.indexOf('Value'))
                    scope.columns.push({
                        field: key, displayName: col, width: w, editableCellTemplate: 'ui-grid/dropdownEditor',
                        cellFilter: 'mapFunction' + scope.DropdwnIdx + ':grid.appScope', resizable: true, enableFiltering: filterFlag //,editDropdownValueLabel: 'Sex',
                    });
                    scope.DropdwnIdx++;
                    return;
                }

                if (key.indexOf('Cust') != -1) {//Custom column
                    col = value.DispName;
                    var colTemp = value.ColTemplate;
                    scope.columns.push({
                        field: value.Name, displayName: col, width: w, cellTemplate: colTemp, resizable: true, enableFiltering: filterFlag //,editDropdownValueLabel: 'Sex',
                    });
                    return;
                }

                GroupByColumn = GroupByColumn.toUpperCase();
                if (GroupByColumn.indexOf(key.toUpperCase()) != -1) {
                    scope.columns.push({ width: w, enableFiltering: filterFlag, field: col, displayName: col, enableCellEdit: true, grouping: { groupPriority: 1 }, sort: { priority: 1, direction: 'asc' }, resizable: true });
                }
                else {
                    //AggregateColumnExpr = AggregateColumnExpr.toUpperCase();
                    if (AggregateColumnExpr.toUpperCase().indexOf(key.toUpperCase()) != -1) {
                        var arrExpr = AggregateColumnExpr.split("(");
                        col = arrExpr[1].substr(0, arrExpr[1].length - 1);
                        if (arrExpr[0].toUpperCase() == 'SUM')
                            scope.columns.push({ field: col, displayName: col, enableCellEdit: EditableFlag, enableFiltering: true, treeAggregationType: uiGridGroupingConstants.aggregation.SUM, width: w, resizable: true });
                        if (arrExpr[0].toUpperCase() == 'MAX')
                            scope.columns.push({ field: col, displayName: col, enableCellEdit: EditableFlag, enableFiltering: true, treeAggregationType: uiGridGroupingConstants.aggregation.MAX, width: w, resizable: true });
                        if (arrExpr[0].toUpperCase() == 'MIN')
                            scope.columns.push({ field: col, displayName: col, enableCellEdit: EditableFlag, enableFiltering: true, treeAggregationType: uiGridGroupingConstants.aggregation.MIN, width: w, resizable: true });
                        if (arrExpr[0].toUpperCase() == 'AVG')
                            scope.columns.push({ field: col, displayName: col, enableCellEdit: EditableFlag, enableFiltering: true, treeAggregationType: uiGridGroupingConstants.aggregation.AVG, width: w, resizable: true });

                    }
                    else {
                        if (key.toUpperCase().indexOf('ID') == 0 && key.length==2) {
                            //scope.columns.push({ visible: false, field: col, displayName: col, enableCellEdit: EditableFlag, enableFiltering: filterFlag, resizable: true });//resizable: true
                        }
                        else {
                            if (key.toUpperCase().indexOf('LVL') != -1) {
                                scope.columns.push({ visible: false, field: col, displayName: col, enableCellEdit: EditableFlag, enableFiltering: filterFlag, resizable: true });
                            }
                            else
                                scope.columns.push({ width: w, field: col, displayName: col, enableCellEdit: EditableFlag, enableFiltering: filterFlag, resizable: true });
                        }
                    }
                }
            })
            //WriteLog('Processed Data');

            var i = 0, j = 0;


            $.each(data[0], function (key, value) {
                //alert($scope.gridOptions.columnDefs[i].displayName);
                var colname = scope.gridOptions.columnDefs[i].displayName;
                if (i < scope.gridOptions.columnDefs.length) {
                    var drpIdx = colname.indexOf('List');
                    if (drpIdx != -1) {
                        scope.Dropdowns[j] = new Array(1);
                        scope.Dropdowns[j] = scope.gridOptions.columnDefs[i - 1].editDropdownOptionsArray = value;//data[0].GenderList;
                        //scope.gridOptions.columnDefs[i].visible = false;

                        j++;
                    }
                }
                if (key.indexOf(colname) == -1) {
                    for (var x = 0; x < data.length; x++) {
                        delete data[x][key];
                    }
                }
                else {
                    i++;
                }

            })

            for (var y = 0; y < scope.gridOptions.columnDefs.length; y++) {
                var colname = scope.gridOptions.columnDefs[y].displayName;
                if (colname.indexOf('List') != -1 || colname.indexOf('Lvl') != -1) {
                    scope.columns.splice(y, 1);
                    y--;
                }
            }

            for (var l = 0; l < data.length; l++) {
                if (data[l].Lvl == 0)
                    data[l].$$treeLevel = 0;
                //else
                //    data[l].$$treeLevel = 1;
            }


            //var pt = /[*^#&@]/g;
            //var jsonData = JSON.stringify(data).split("\":")
            //var clrdata = "";
            //for (var i = 0; i < jsonData.length; i++) {
            //    var ind = jsonData[i].search(pt);
            //    var clrkey = (ind != -1) ? jsonData[i].substr(0, ind) : jsonData[i];
            //    //alert(clrkey);
            //    clrdata = clrdata + clrkey + "\":";
            //}
            //clrdata = clrdata.substr(0, clrdata.length - 2);
            //clrdata = JSON.parse(clrdata);
            //scope.gridOptions.data = clrdata;
            scope.gridOptions.data = data;
            //WriteLog('Binded Data');
        }
        catch (err) {
            //message.innerHTML = err.message;
            alert(err.message);
        }
    });
}



var app = angular.module('app', [ 'ngTouch', 'ui.grid', 'ui.grid.resizeColumns', 'ui.grid.selection', 'ui.grid.expandable']);
app.controller('GridController1', ['$scope', '$http', '$interval', 'uiGridGroupingConstants', function ($scope, $http, $interval, uiGridGroupingConstants) {
    $scope.Dropdowns = new Array(6);
    $scope.DropdwnIdx = 0;
    $scope.columns = [];
    $scope.gridOptions = {
        columnDefs: $scope.columns,
        //treeRowHeaderAlwaysVisible: false,
        //enableCellEditOnFocus: true,
        //enableSorting: false,
        //enableFiltering: false,
        //enableHorizontalScrollbar: false,
        //enableGridMenu: false,
        //expandableRowTemplate: 'expandableRowTemplate.html',
        //expandableRowHeight: 150,
        //subGridVariable will be available in subGrid scope
        //expandableRowScope: {
        //    subGridVariable: 'subGridScopeVariable'
        //},
        onRegisterApi: function (gridApi) {
            $scope.gridApi = gridApi;
            //gridApi.core.on.rowsRendered($scope, function () {
            //    if (!gridApi.grid.expandable.expandedAll && !initialized) {
            //        gridApi.expandable.expandAllRows();
            //        initialized = true;
            //    }
            //});


        }





    };
    //debugger;
    $scope.init = function (grid, Actioname, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList) {
        CreateCustomGrid($http, grid, Actioname, uiGridGroupingConstants, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList);//, Dropdowns, DropdwnIdx
    };     
    $scope.save = function (grid, Actioname) {
        alert('saveinternal4');
        SaveCustomGrid(grid, Actioname);
    }
    $scope.Autofill = function (rowRenderIndex) {
        alert(rowRenderIndex);
    };
    $scope.expandAllRows = function () {
        var scope = angular.element($("#grid1")).scope();
        scope.gridApi.expandable.expandAllRows();
        //headerButtonClick($event)
        //gridApi.edit.on.beginCellEdit($scope, function (rowEntity, colDef, newValue, oldValue) {
        //    alert("Yessssssssss !!");
        //    alert(newValue);

        //});
        //gridApi.expandable.on.rowExpandedStateChanged($scope, function(row){
        //        var height = parseInt(uiGridService.removeUnit($scope.jdeNewUserConflictsGridHeight,'px'));
        //        var changedRowHeight = parseInt(uiGridService.getGridHeight(row.entity.subGridNewUserConflictsGrid, true));

        //        if (row.isExpanded)
        //        {
        //            height += changedRowHeight;                    
        //        }
        //        else
        //        {
        //            height -= changedRowHeight;                    
        //        }

        //        $scope.jdeNewUserConflictsGridHeight = height + 'px';
        //    });
    }

    $scope.collapseAllRows = function () {
        var scope = angular.element($("#grid1")).scope();
        scope.gridApi.expandable.collapseAllRows();
    }
    }])


app.controller('GridController2', ['$scope', '$http', '$interval', 'uiGridGroupingConstants', function ($scope, $http, $interval, uiGridGroupingConstants) {
    $scope.Dropdowns = new Array(6);
    $scope.DropdwnIdx = 0;
    $scope.columns = [];
    $scope.gridOptions = {
        columnDefs: $scope.columns,
        treeRowHeaderAlwaysVisible: false,
        enableCellEditOnFocus: true,
        //enableSorting: false,
        //enableFiltering: false,
        //enableHorizontalScrollbar: false,
        //enableGridMenu: false,
        onRegisterApi: function (gridApi) {
            $scope.gridApi = gridApi;
        }
    };
    //debugger;
    $scope.init = function (grid, Actioname, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList) {
        CreateCustomGrid($http, grid, Actioname, uiGridGroupingConstants, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList);//, Dropdowns, DropdwnIdx
    };
    $scope.save = function (grid, Actioname) {
        alert('saveinternal5');
        SaveCustomGrid(grid, Actioname);
    }
    $scope.Autofill = function (rowRenderIndex) {
        alert('hi');
    };
}])

app.controller('GridController3', ['$scope', '$http', '$interval', 'uiGridGroupingConstants', function ($scope, $http, $interval, uiGridGroupingConstants) {
    $scope.Dropdowns = new Array(6);
    $scope.DropdwnIdx = 0;
    $scope.columns = [];
    $scope.gridOptions = {
        columnDefs: $scope.columns,
        treeRowHeaderAlwaysVisible: false,
        enableCellEditOnFocus: true,
        //enableSorting: false,
        //enableFiltering: false,
        //enableHorizontalScrollbar: false,
        //enableGridMenu: false,
        onRegisterApi: function (gridApi) {
            $scope.gridApi = gridApi;
        }
    };
    //debugger;
    $scope.init = function (grid, Actioname, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList) {
        CreateCustomGrid($http,grid, Actioname, uiGridGroupingConstants, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList);//, Dropdowns, DropdwnIdx
    };
    $scope.save = function (grid, Actioname) {
        alert('saveinternal6');
        SaveCustomGrid(grid, Actioname);
    }
    $scope.Autofill = function (rowRenderIndex) {
        alert(rowRenderIndex);
    };
    $scope.expandAllRows = function () {
        var scope = angular.element($("#grid12" )).scope();
        scope.gridApi.expandable.expandAllRows();
    }

    $scope.collapseAllRows = function () {
        var scope = angular.element($("#grid12")).scope();
        scope.gridApi.expandable.collapseAllRows();
    }
}])

app.controller('GridController4', ['$scope', '$http', '$interval', 'uiGridGroupingConstants', function ($scope, $http, $interval, uiGridGroupingConstants) {
    $scope.Dropdowns = new Array(6);
    $scope.DropdwnIdx = 0;
    $scope.columns = [];
    $scope.gridOptions = {
        columnDefs: $scope.columns,
        treeRowHeaderAlwaysVisible: false,
        enableCellEditOnFocus: true,
        //enableSorting: false,
        //enableFiltering: false,
        //enableHorizontalScrollbar: false,
        //enableGridMenu: false,
        onRegisterApi: function (gridApi) {
            $scope.gridApi = gridApi;
        }
    };
    //debugger;
    $scope.init = function (grid, Actioname, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList) {
        CreateCustomGrid($http, grid, Actioname, uiGridGroupingConstants, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList);//, Dropdowns, DropdwnIdx
    };
    $scope.save = function (grid, Actioname) {
        alert('saveinternal7');
        SaveCustomGrid(grid, Actioname);
    }
}])
app.controller('GridController5', ['$scope', '$http', '$interval', 'uiGridGroupingConstants', function ($scope, $http, $interval, uiGridGroupingConstants) {
    $scope.Dropdowns = new Array(6);
    $scope.DropdwnIdx = 0;
    $scope.columns = [];
    $scope.gridOptions = {
        columnDefs: $scope.columns,
        treeRowHeaderAlwaysVisible: false,
        enableCellEditOnFocus: true,
        //enableSorting: false,
        //enableFiltering: false,
        //enableHorizontalScrollbar: false,
        //enableGridMenu: false,
        onRegisterApi: function (gridApi) {
            $scope.gridApi = gridApi;
        }
    };
    //debugger;
    $scope.init = function (grid, Actioname, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList) {
        CreateCustomGrid($http, grid, Actioname, uiGridGroupingConstants, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList);//, Dropdowns, DropdwnIdx
    };
    $scope.save = function (grid, Actioname) {
        alert('saveinternal8');
        SaveCustomGrid(grid, Actioname);
    }
}])

app.controller('GridController6', ['$scope', '$http', '$interval', 'uiGridGroupingConstants', function ($scope, $http, $interval, uiGridGroupingConstants) {
    $scope.Dropdowns = new Array(6);
    $scope.DropdwnIdx = 0;
    $scope.columns = [];
    $scope.gridOptions = {
        columnDefs: $scope.columns,
        treeRowHeaderAlwaysVisible: false,
        enableCellEditOnFocus: true,
        //enableSorting: false,
        //enableFiltering: false,
        //enableHorizontalScrollbar: false,
        //enableGridMenu: false,
        onRegisterApi: function (gridApi) {
            $scope.gridApi = gridApi;
        }
    };
    //debugger;
    $scope.init = function (grid, Actioname, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList) {
        CreateCustomGrid($http, grid, Actioname, uiGridGroupingConstants, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList);//, Dropdowns, DropdwnIdx
    };

    $scope.save = function (grid, Actioname) {
        alert('saveinternal9');
        SaveCustomGrid(grid, Actioname);
    }
}])
app.controller('GridController7', ['$scope', '$http', '$interval', 'uiGridGroupingConstants', function ($scope, $http, $interval, uiGridGroupingConstants) {
    $scope.Dropdowns = new Array(6);
    $scope.DropdwnIdx = 0;
    $scope.columns = [];
    $scope.gridOptions = {
        columnDefs: $scope.columns,
        treeRowHeaderAlwaysVisible: false,
        enableCellEditOnFocus: true,
        //enableSorting: false,
        //enableFiltering: false,
        //enableHorizontalScrollbar: false,
        //enableGridMenu: false,
        onRegisterApi: function (gridApi) {
            $scope.gridApi = gridApi;
        }
    };
    //debugger;
    $scope.init = function (grid, Actioname, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList) {
        CreateCustomGrid($http, grid, Actioname, uiGridGroupingConstants, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList);//, Dropdowns, DropdwnIdx
    };
    $scope.save = function (grid, Actioname) {
        alert('Saveinternal')
        SaveCustomGrid(grid, Actioname);
    }
}])
app.controller('GridController8', ['$scope', '$http', '$interval', 'uiGridGroupingConstants', function ($scope, $http, $interval, uiGridGroupingConstants) {
    $scope.Dropdowns = new Array(6);
    $scope.DropdwnIdx = 0;
    $scope.columns = [];
    $scope.gridOptions = {
        columnDefs: $scope.columns,
        treeRowHeaderAlwaysVisible: false,
        enableCellEditOnFocus: true,
        //enableSorting: false,
        //enableFiltering: false,
        //enableHorizontalScrollbar: false,
        //enableGridMenu: false,
        onRegisterApi: function (gridApi) {
            $scope.gridApi = gridApi;
        }
    };
    //debugger;
    $scope.init = function (grid, Actioname, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList) {
        CreateCustomGrid($http, grid, Actioname, uiGridGroupingConstants, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList);//, Dropdowns, DropdwnIdx
    };
    $scope.save = function (grid, Actioname) {
        alert('Saveinternal1')
        SaveCustomGrid(grid, Actioname);
    }
}])
app.controller('GridController9', ['$scope', '$http', '$interval', 'uiGridGroupingConstants', function ($scope, $http, $interval, uiGridGroupingConstants) {
    $scope.Dropdowns = new Array(6);
    $scope.DropdwnIdx = 0;
    $scope.columns = [];
    $scope.gridOptions = {
        columnDefs: $scope.columns,
        treeRowHeaderAlwaysVisible: false,
        enableCellEditOnFocus: true,
        //enableSorting: false,
        //enableFiltering: false,
        //enableHorizontalScrollbar: false,
        //enableGridMenu: false,
        onRegisterApi: function (gridApi) {
            $scope.gridApi = gridApi;
        }
    };
    //debugger;
    $scope.init = function (grid, Actioname, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList) {
        CreateCustomGrid($http, grid, Actioname, uiGridGroupingConstants, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList);//, Dropdowns, DropdwnIdx
    };
    $scope.save = function (grid, Actioname) {

        alert('Saveinternal2');
        SaveCustomGrid(grid, Actioname);
    }
}])
app.controller('GridController10', ['$scope', '$http', '$interval', 'uiGridGroupingConstants', function ($scope, $http, $interval, uiGridGroupingConstants) {
    $scope.Dropdowns = new Array(6);
    $scope.DropdwnIdx = 0;
    $scope.columns = [];
    $scope.gridOptions = {
        columnDefs: $scope.columns,
        treeRowHeaderAlwaysVisible: false,
        enableCellEditOnFocus: true,
        //enableSorting: false,
        //enableFiltering: false,
        //enableHorizontalScrollbar: false,
        //enableGridMenu: false,
        onRegisterApi: function (gridApi) {
            $scope.gridApi = gridApi;
        }
    };
    //debugger;
    $scope.init = function (grid, Actioname, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList) {
        CreateCustomGrid($http, grid, Actioname, uiGridGroupingConstants, asyncall, gridoption, GroupByColumn, AggregateColumnExpr, visibleColListWithWidthnHight, filterColList, EditableColList);//, Dropdowns, DropdwnIdx
    };
    $scope.save = function (grid, Actioname) {
        alert('saveinternal3')
        SaveCustomGrid(grid, Actioname);
    }
}])
.filter('mapFunction0', function () {
    return function (input, scope) {
        if (!input) {
            return '';
        } else {
            // alert(scope.i);
            //var scope = angular.element($("#" + Gridid)).scope();
            //alert(scope.i + "-" + scope.j);
            for (var i = 0; i < scope.Dropdowns[0].length; i++) {
                var item = scope.Dropdowns[0][i];
                if (item.id == input) {
                    return item.value;
                }
            }

        }
    };
})
.filter('mapFunction1', function () {
    return function (input, scope) {
        if (!input) {
            return '';
        } else {
            for (var i = 0; i < scope.Dropdowns[1].length; i++) {
                var item = scope.Dropdowns[1][i];
                if (item.id == input) {
                    return item.value;
                }
            }

        }
    };
})
.filter('mapFunction2', function () {
    return function (input, scope) {
        if (!input) {
            return '';
        } else {
            for (var i = 0; i < scope.Dropdowns[2].length; i++) {
                var item = scope.Dropdowns[2][i];
                if (item.id == input) {
                    return item.value;
                }
            }

        }
    };
})
.filter('mapFunction3', function () {
    return function (input, scope) {
        if (!input) {
            return '';
        } else {
            // alert(scope.i);
            //var scope = angular.element($("#" + Gridid)).scope();
            //alert(scope.i + "-" + scope.j);
            for (var i = 0; i < scope.Dropdowns[3].length; i++) {
                var item = scope.Dropdowns[3][i];
                if (item.id == input) {
                    return item.value;
                }
            }

        }
    };
})
.filter('mapFunction4', function () {
    return function (input, scope) {
        if (!input) {
            return '';
        } else {
            for (var i = 0; i < scope.Dropdowns[4].length; i++) {
                var item = scope.Dropdowns[4][i];
                if (item.id == input) {
                    return item.value;
                }
            }

        }
    };
})
.filter('mapFunction5', function () {
    return function (input, scope) {
        if (!input) {
            return '';
        } else {
            for (var i = 0; i < scope.Dropdowns[5].length; i++) {
                var item = scope.Dropdowns[5][i];
                if (item.id == input) {
                    return item.value;
                }
            }

        }
    };
})
.filter('mapFunction6', function () {
    return function (input, scope) {
        if (!input) {
            return '';
        } else {
            for (var i = 0; i < scope.Dropdowns[6].length; i++) {
                var item = scope.Dropdowns[6][i];
                if (item.id == input) {
                    return item.value;
                }
            }

        }
    };
})


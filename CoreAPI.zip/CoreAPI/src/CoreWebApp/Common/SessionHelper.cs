﻿using System;
using System.Web;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.SessionState;
using System.Web.Configuration;
using System.Web.Security;

namespace company.CIO.IOSM.ROM.Common
{
    public static class SessionHelper
    {


        public static List<T> GetCollectionFromSession<T>(string sessionID)
        {
            if (System.Web.HttpContext.Current.Session[sessionID] != null)
            {
                return (List<T>)System.Web.HttpContext.Current.Session[sessionID];
            }
            return null;
        }

        public static T GetFromSession<T>(string sessionID)
        {
            if (System.Web.HttpContext.Current.Session[sessionID] != null)
            {
                return (T)System.Web.HttpContext.Current.Session[sessionID];
            }
            return default(T);
        }

        public static void SaveCollectionInSession<T>(string sessionID, List<T> collectionToSave)
        {
            System.Web.HttpContext.Current.Session[sessionID] = collectionToSave;
        }
        public static void SaveInSession<T>(string sessionID, T itemToSave)
        {
            System.Web.HttpContext.Current.Session[sessionID] = itemToSave;
        }
        public static void AddItemToExistingCollection<T>(string sessionID, T itemToAdd)
        {
            ((List<T>)System.Web.HttpContext.Current.Session[sessionID]).Add(itemToAdd);
        }
        public static void RemoveItemFromExistingCollection<T>(string sessionID, T itemToRemove)
        {
            ((List<T>)System.Web.HttpContext.Current.Session[sessionID]).Remove(itemToRemove);
        }
    }
}

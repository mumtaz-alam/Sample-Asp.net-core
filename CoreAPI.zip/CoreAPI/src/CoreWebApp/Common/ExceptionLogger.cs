﻿using ROM.Web.Properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Practices.EnterpriseLibrary.Logging;

namespace ROM.Web.ViewModels
{
    public class ExceptionLogger
    {

        public static void LogAsynchronousCallException(string MethodName, HttpResponseBase Response, Exception ex, string ResourceFileFailureMsgKey)
        {
            string errorMsg = "";

            if (ex is ApplicationException)
            {
                errorMsg = ex.Message;
            }
            else
            {
                Logger.Write(MethodName +  " : " + ex.Message + " Inner Exception: " + ex.InnerException + " Stack Trace: " + ex.StackTrace + " at: " + DateTime.Now);
                errorMsg = Resources.ResourceManager.GetString(ResourceFileFailureMsgKey);
            }

            Response.StatusCode = 500;
            Response.Write(errorMsg);
            
        }

    }
}
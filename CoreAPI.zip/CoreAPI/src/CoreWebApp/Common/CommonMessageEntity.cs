﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace company.CIO.IOSM.ROM.Common
{
    /// <summary>
    /// CommonMessageEntity for showing success,error and hard error messages
    /// </summary>
    public class CommonMessageEntity
    {
        public string MsgSuccessError { get; set; }
        public int MsgType { get; set; }
    }
}

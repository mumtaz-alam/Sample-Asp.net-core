﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreWebApp.ViewModels
{
    public class Student
    {
        //public Students()
        //{
        //    Marks = new HashSet<Marks>();
        //}

        public int RollId { get; set; }
        public string Name { get; set; }

        //public virtual ICollection<Marks> Marks { get; set; }
    }
}

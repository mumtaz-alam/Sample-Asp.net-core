﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreAPI.Models
{
    public class StudentRepository : IStudentRepository
    {
        private static ConcurrentDictionary<int, Student> _stus =
             new ConcurrentDictionary<int, Student>();
        private StudentsDBContext _context;
        public StudentRepository(StudentsDBContext context)
        {
            //Add(new Student { Name = "Item1" });
            _context = context;
        }
        public void Add(Student item)
        {
            //item.RollId = _stus.Count()+1;
            //_stus[item.RollId] = item;

                _context.Students.Add(item);
                _context.SaveChanges();

        }

        public Student Find(int key)
        {
            Student item;
            _stus.TryGetValue(key, out item);
            return item;
        }

        public IEnumerable<Student> GetAll()
        {
           return _context.Students.ToList();
            //return _stus.Values;
        }

        public Student Remove(int key)
        {
            Student item;
            _stus.TryRemove(key, out item);
            return item;
        }

        public void Update(Student item)
        {
            _stus[item.RollId] = item;
        }
    }
}

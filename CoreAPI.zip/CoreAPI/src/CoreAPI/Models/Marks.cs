﻿using System;
using System.Collections.Generic;

namespace CoreAPI.Models
{
    public partial class Marks
    {
        public int MarkId { get; set; }
        public int RollId { get; set; }
        public string Content { get; set; }
        public string Title { get; set; }

        public virtual Student Roll { get; set; }
    }
}

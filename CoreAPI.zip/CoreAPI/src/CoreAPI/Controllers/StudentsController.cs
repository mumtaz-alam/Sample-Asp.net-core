﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CoreAPI.Models;
// For more information on enabling Web API for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace CoreAPI.Controllers
{
    [Route("api/[controller]")]
    public class StudentsController : Controller
    {
        public IStudentRepository stds { get; set; }
        public StudentsController(IStudentRepository todoItems)
        {
            stds = todoItems;
        }
        // GET api/values
        [HttpGet]
        public IEnumerable<Student> Get()
        {
            //return null;
            //return new string[] { "value1", "value2" };
            return stds.GetAll();
        }

        //// GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }
        [HttpGet("GetAll")]
        public IEnumerable<Student> GetAll()
        {
            return stds.GetAll();
        }
        // POST api/values
        [HttpPost]
        public void Post(Student item)
        {
        }

        // PUT api/values/5
        [HttpPut]
        public void Put([FromBody]Student item)
        {
            if (item != null)
            {
                stds.Add(item); 
            }
                     
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
        [HttpPost]
        public IActionResult Create([FromBody] Student item)
        {
            if (item == null)
            {
                return BadRequest();
            }
            stds.Add(item);
            return CreatedAtRoute("GetStudents", new { id = item.RollId }, item);
        }
        //public StudentsController(IStudentRepository todoItems)
        //{
        //    TodoItems = todoItems;
        //}
        //public IStudentRepository TodoItems { get; set; }
        //[HttpGet]
        //public IEnumerable<Student> GetAll()
        //{
        //    return TodoItems.GetAll();
        //}

        //[HttpGet("{id}", Name = "GetStudent")]
        //public IActionResult GetById(int id)
        //{
        //    var item = TodoItems.Find(id);
        //    if (item == null)
        //    {
        //        return NotFound();
        //    }
        //    return new ObjectResult(item);
        //}
        //// GET: api/values
        //[HttpGet]
        //public IEnumerable<string> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        //// GET api/values/5
        //[HttpGet("{id}")]
        //public string Get(int id)
        //{
        //    return "value";
        //}

        //// POST api/values
        //[HttpPost]
        //public void Post([FromBody]string value)
        //{
        //}

        //// PUT api/values/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody]string value)
        //{
        //}

        //// DELETE api/values/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
    }
}

﻿using Microsoft.EntityFrameworkCore;


namespace CoreAPI.DAL
{
    public interface IEntityMap
    {
        void Map(ModelBuilder modelBuilder);
    }
}
